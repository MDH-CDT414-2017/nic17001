/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bowlinggame.BowlingGame;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nermin
 */
public class BowlingGameTest {
    
    public BowlingGameTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    
    // checking is string valid
        
    @Test
    public void stringDoesntStartOrEndWithSquareBracket() {
        
        BowlingGame bowlingGame = new BowlingGame("1234");
        
        assertEquals(-1, bowlingGame.getScore());
    }
    
    @Test
    public void stringDoesntContainSameNumberOfBrackets() {
        
        BowlingGame bowlingGame = new BowlingGame("[[]][");
        
        assertEquals(-1, bowlingGame.getScore());
    }
    
    @Test 
    public void faultFormatOfResultLeftBracket() {
        
        BowlingGame bowlingGame = new BowlingGame("[3,4[][4]");
        
        assertEquals(-1, bowlingGame.getScore());
    }
    
    @Test 
    public void faultFormatOfResultRightBracket() {
        
        BowlingGame bowlingGame = new BowlingGame("[]]");
        
        assertEquals(-1, bowlingGame.getScore());
    } 
    
    @Test 
    public void BadCharacterInput() {
        
        BowlingGame bowlingGame = new BowlingGame("[a,b]");
        
        assertEquals(-1, bowlingGame.getScore());
    }
    
    @Test 
    public void BadIntputByRegex() {
        
        BowlingGame bowlingGame = new BowlingGame("[,]");
        
        assertEquals(-1, bowlingGame.getScore());
    }
    
    @Test
    public void resultOpen() {
        
        BowlingGame bowlingGame = new BowlingGame("[1,5][3,6][7,2][3,6][4,4][5,3][3,3][4,5][8,1][2,6]");
    
        assertEquals(81, bowlingGame.getScore());
    }
    
    @Test
    public void resultStrike() {
        
        BowlingGame bowlingGame = new BowlingGame("[10,0][3,6][7,2][3,6][4,4][5,3][3,3][4,5][8,1][2,6]");
        
        assertEquals(94, bowlingGame.getScore());
    }
    
    @Test
    public void resultMultipleStrike() {
        
        BowlingGame bowlingGame = new BowlingGame("[10,0][10,0][7,2][3,6][4,4][5,3][3,3][4,5][8,1][2,6]");
        
        assertEquals(112, bowlingGame.getScore());
    }
    
    @Test
    public void resultSpare() {
        
        BowlingGame bowlingGame = new BowlingGame("[1,9][3,6][7,2][3,6][4,4][5,3][3,3][4,5][8,1][2,6]");
        
        assertEquals(88, bowlingGame.getScore());
    }

    @Test
    public void resultMultipleSpare() {
        
        BowlingGame bowlingGame = new BowlingGame("[8,2][5,5][7,2][3,6][4,4][5,3][3,3][4,5][8,1][2,6]");

        assertEquals(98, bowlingGame.getScore());
    }
    
    @Test
    public void resultStrikeSpare() {
        
        BowlingGame bowlingGame = new BowlingGame("[10,0][4,6][7,2][3,6][4,4][5,3][3,3][4,5][8,1][2,6]");

        assertEquals(103, bowlingGame.getScore());
    }
    
    @Test
    public void resultSpareLastFrame() {
    
        BowlingGame bowlingGame = new BowlingGame("[1,5][3,6][7,2][3,6][4,4][5,3][3,3][4,5][8,1][2,8][7]");
    
        assertEquals(90, bowlingGame.getScore());
    }

    @Test
    public void resultSpareStrikeLastFrame() {
    
        BowlingGame bowlingGame = new BowlingGame("[1,5][3,6][7,2][3,6][4,4][5,3][3,3][4,5][8,1][2,8][10]");
    
        assertEquals(93, bowlingGame.getScore());
    }
    
    @Test
    public void resultStrikeLastFrame() {
        
        BowlingGame bowlingGame = new BowlingGame("[1,5][3,6][7,2][3,6][4,4][5,3][3,3][4,5][8,1][10,0][7,2]");

        assertEquals(92, bowlingGame.getScore());
    }
    
    @Test 
    public void resultMaximum() {
        
        BowlingGame bowlingGame = new BowlingGame("[10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,10]");
        
        assertEquals(300, bowlingGame.getScore());
    }
}
