/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bowlinggame.BowlingGame;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nermin
 */
public class BowlingGameTest {
    
    public BowlingGameTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    
    // checking is string valid
        
    @Test
    public void stringDoesntStartOrEndWithSquareBracket() {
        
        BowlingGame bowlingGame = new BowlingGame("1234");
        
        assertEquals(-1, bowlingGame.getScore());
    }
    
    @Test
    public void stringDoesntContainSameNumberOfBrackets() {
        
        BowlingGame bowlingGame = new BowlingGame("[[]][");
        
        assertEquals(-1, bowlingGame.getScore());
    }
    
    @Test 
    public void faultFormatOfResultLeftBracket() {
        
        BowlingGame bowlingGame = new BowlingGame("[3,4[][4]");
        
        assertEquals(-1, bowlingGame.getScore());
    }
    
    @Test 
    public void faultFormatOfResultRightBracket() {
        
        BowlingGame bowlingGame = new BowlingGame("[]]");
        
        assertEquals(-1, bowlingGame.getScore());
    }
}
