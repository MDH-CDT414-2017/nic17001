/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bowlinggame;

import com.sun.xml.internal.ws.util.StringUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 *
 * @author nermin
 */
public class BowlingGame {
    
    private String resultInput;

    public String getResultInput() {
        return resultInput;
    }

    public BowlingGame(String resultInput) {
        
        this.resultInput = resultInput;
    }
    
    private int countElement(char element) {
        
        int count = 0;

        for (char ch: resultInput.toCharArray()) { 
            if (ch == element) {
                count++;
            }
        }
    
        return count;
    }
    
    public boolean goodBrackets() {
        
        String[] array = resultInput.split(""); 
        
        boolean left_bracket_started = true; 
        boolean right_bracket_ended = false;
        
        
        for (int i = 0; i < array.length; i++) {
                        
            if (i > 0 && left_bracket_started && array[i].equals("["))
                return false;
            
            if (right_bracket_ended && array[i].equals("]"))
                return false;
            
            if (left_bracket_started && array[i].equals("]")) {
                
                right_bracket_ended = true;
                left_bracket_started = false;
                
                
            } 
            
            if (i != array.length - 1 && right_bracket_ended && array[i + 1].equals("[")) {
                right_bracket_ended = false;
                left_bracket_started = true;
                
                
                i++;
            }
                
        }
                
        for (int i = 0; i < array.length - 1; i++)
            if (array[i].equals("]"))
                if (!array[i+1].equals("["))
                    return false;
            
        
        return true;
    }
    
    public boolean goodCharacterInput() {
        
        List<String> listOfCharacters= new ArrayList<>(Arrays.asList("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", ",", "[", "]"));
        
        String[] array = resultInput.split("");
        
        for (String element : array) {
            if (!listOfCharacters.contains(element)) {
                return false;
            }
        }
        
        return true;
    }
    
    public boolean goodComma() {
        
        boolean left_bracket_started = true; 
        boolean right_bracket_ended = false;
        boolean comma = false;
        
        String[] array = resultInput.split(""); 

        for (int i = 0; i < array.length - 1; i++) {

            if (left_bracket_started && array[i] == ",") {
                
                comma = true;
                left_bracket_started = false;
            }
            
            if (comma == true && array[i] == "]" && array[i + 1] == "[")
            {
                left_bracket_started = true;
                comma = false;
            }
            
        }
        
        return true;
    }
    
    public boolean goodInput() {
        
//        String regex = "(\\[(?:\\d,\\d|10,0)\\]){10}";
        
        String regex = "(\\[(?:\\d,\\d|10,0)\\]){10}(?:\\[\\d\\]|\\[\\d,\\d\\]|\\[10,10\\]|\\[\\d,10\\]|\\[10,\\d\\]|\\[10\\]){0,1}";
        
        Pattern pattern = Pattern.compile(regex);
        
        Matcher matcher = pattern.matcher(resultInput);
        
        if (!matcher.matches()) {
  
            return false;
        } 
        
        return true;
       
    }
    

    public int getScore() {
        
        int number_of_points = 0;
        
        if (!resultInput.startsWith("[") || !resultInput.endsWith("]")) {
            return -1;
        }
        
        if (countElement('[') != countElement(']'))
            return -1;
              
        if (!goodBrackets())
            return -1;
        
        if (!goodComma())
            return -1;
        
        if (!goodCharacterInput())
            return -1;
        
        if (!goodInput())
            return -1;
        
        List<Integer> points = splitInput();
        
        // max_result
        
        boolean max_result = false;
        
        if (points.size() == 22) {
            
            for (int i = 0; i < points.size(); i += 2)
                if (points.get(i) == 10 && points.get(i) == 10)
                    max_result = true;
                else {
                    max_result = false;
                    break;
                }
            
            if (max_result)
                return 300;
        } 
            
        // last element cannot be [10,0] in regular 
        
        if (points.size() == 20 && points.get(18) == 10 && points.get(19) == 0)
            return -1;
        
        if (points.size() % 2 == 0) // check if last element is not spare
            for (int i = 0; i < points.size() - 1; i += 2) {
                
                if (points.size() == 22 && i == 18) {

                    if ( points.get(i) == 10 && points.get(i + 1) == 0 ) {
                        
                        number_of_points += points.get(i) + points.get(i + 2) + points.get(i + 3);
                        
                        return number_of_points;
                    } else 
                        return -1;
                } else {

                    if (points.get(i) == 10 && points.get(i + 2) == 10 && i < points.size() - 4) { // multiple strike
                        number_of_points += points.get(i) + points.get(i + 2) + points.get(i + 4);
                    } else if (points.get(i) == 10 && i < points.size() - 2) { // strike
                        number_of_points += points.get(i) + points.get(i + 2) + points.get(i + 3);
                    } else if (points.get(i) + points.get(i + 1) == 10 && i < points.size() - 2) {  // spare
                        number_of_points += points.get(i) + points.get(i + 1) + points.get(i + 2);
                    } else if (points.get(i) + points.get(i + 1) != 10) {
                        number_of_points += points.get(i) + points.get(i + 1);
                    }
                
                }
                
                
            }
        else 
            for (int i = 0; i < points.size() - 2; i += 2) {
                if (i == points.size() - 3) {
                    if (points.get(i) + points.get(i + 1) == 10)
                        number_of_points += points.get(i) + points.get(i + 1) + points.get(i + 2);
                    else 
                        return - 1;
                } else {
                    
                    if (points.get(i) == 10 && points.get(i + 2) == 10 && i < points.size() - 5) { // multiple strike
                        number_of_points += points.get(i) + points.get(i + 2) + points.get(i + 4);
                    } else if (points.get(i) == 10) { // strike
                        number_of_points += points.get(i) + points.get(i + 2) + points.get(i + 3);
                    } else if (points.get(i) + points.get(i + 1) == 10) {  // spare
                        number_of_points += points.get(i) + points.get(i + 1) + points.get(i + 2);
                    } else if (points.get(i) + points.get(i + 1) != 10) {
                        number_of_points += points.get(i) + points.get(i + 1);
                    }
                
                }         
               
            }
        
                
        return number_of_points;
    }
    
    public List<Integer> splitInput() {
        
        
        String newStr = resultInput.replaceAll("\\[", "");

        List<String> items = Arrays.asList(newStr.split(",|]"));        
        
                
        System.out.println(items.size());
        
        List<Integer> numbers = new ArrayList<Integer>(); 
        
        for (String s : items) 
            numbers.add(Integer.valueOf(s));
    
        return numbers;
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        BowlingGame bowlingGame = new BowlingGame("[1,5][3,6][7,2][3,6][4,4][5,3][3,3][4,5][8,1][10,0][7,2]");
        
        List<Integer> i = bowlingGame.splitInput();
    
    }
}
