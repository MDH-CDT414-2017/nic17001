/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bowlinggame;

import com.sun.xml.internal.ws.util.StringUtils;


/**
 *
 * @author nermin
 */
public class BowlingGame {
    
    private String resultInput;

    public String getResultInput() {
        return resultInput;
    }

    public BowlingGame(String resultInput) {
        
        this.resultInput = resultInput;
    }
    
    private int countElement(char element) {
        
        int count = 0;

        for (char ch: resultInput.toCharArray()) { 
            if (ch == element) {
                count++;
            }
        }
    
        return count;
    }
    
    public boolean goodBrackets() {
        
        String[] array = resultInput.split(""); 
        
        boolean left_bracket_started = true; 
        boolean right_bracket_ended = false;
        
        System.out.print("[");
        
        for (int i = 0; i < array.length; i++) {
                        
            if (i > 0 && left_bracket_started && array[i].equals("["))
                return false;
            
            if (right_bracket_ended && array[i].equals("]"))
                return false;
            
            if (left_bracket_started && array[i].equals("]")) {
                
                right_bracket_ended = true;
                left_bracket_started = false;
                
                System.out.print("]");
                
            } 
            
            if (i != array.length - 1 && right_bracket_ended && array[i + 1].equals("[")) {
                right_bracket_ended = false;
                left_bracket_started = true;
                
                System.out.print("[");
                
                i++;
            }
                
        }
                
        for (int i = 0; i < array.length - 1; i++)
            if (array[i].equals("]"))
                if (!array[i+1].equals("["))
                    return false;
            
        System.out.println();
        
        return true;
    }
    

    public int getScore() {
        
        if (!resultInput.startsWith("[") || !resultInput.endsWith("]")) {
            return -1;
        }
        
        if (countElement('[') != countElement(']'))
            return -1;
              
        if (!goodBrackets())
            return -1;
        
        return 0;
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        BowlingGame bowlingGame = new BowlingGame("[1,2][13,21][]");
        
        boolean ff = bowlingGame.goodBrackets();
    }
    
}
